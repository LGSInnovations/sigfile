/*

 File: matfile.js
 Copyright (c) 2012-2017, LGS Innovations Inc., All rights reserved.

 This file is part of SigPlot.

 Licensed to the LGS Innovations (LGS) under one
 or more contributor license agreements.  See the NOTICE file
 distributed with this work for additional information
 regarding copyright ownership.  LGS licenses this file
 to you under the Apache License, Version 2.0 (the
 "License"); you may not use this file except in compliance
 with the License.  You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing,
 software distributed under the License is distributed on an
 "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 KIND, either express or implied.  See the License for the
 specific language governing permissions and limitations
 under the License.
*/
(function(m){function s(a){return 0<=a&&31>a?1<<a:s[a]||(s[a]=Math.pow(2,a))}function q(a){a=new Uint8Array(a);if(t)return String.fromCharCode.apply(null,a);for(var f="",d=0;d<a.length;d++)f+=String.fromCharCode(a[d]);return f}function v(a,f,d,b){var e=[];new DataView(a,f,d);if("miINT8"===b)a=new Int8Array(a,f,d);else if("miUINT8"===b)a=new Uint8Array(a,f,d);else if("miINT16"===b)a=new Int16Array(a,f,d);else if("miUINT16"===b)a=new Uint16Array(a,f,d);else if("miINT32"===b)a=new Int32Array(a,f,d);
else if("miUINT32"===b)a=new Uint32Array(a,f,d);else if("miDOUBLE"===b)a=new Float64Array(a,f,d);else{window.console.warn("Array data type not supported yet.");return}a.forEach(function(a){e.push(a)});return e}function n(a,f,d,b){var e;switch(f){case "miINT8":e=a.getInt8(d,b);break;case "miUINT8":e=a.getInt8(d,b);break;case "miINT16":e=a.getInt16(d,b);break;case "miUINT16":e=a.getUint16(d,b);break;case "miINT32":e=a.getInt32(d,b);break;case "miUINT32":e=a.getUint32(d,b);break;case "miSINGLE":e=a.getFloat32(d,
b);break;case "miDOUBLE":e=a.getFloat64(d,b);break;case "miINT64":var c;f=Math.pow(2,53);b?(c=4,e=0):(c=0,e=4);c=a.getInt32(d+c,b);a=a.getInt32(d+e,b)+s(32)*c;a>=f?(window.console.info("Int is bigger than JS can represent."),e=Infinity):e=a;break;default:window.console.warn(f+" not supported at thsi time")}return e}function l(a,f){this.file_name=this.file=null;this.buf=a;if(null!=this.buf){var d=new DataView(this.buf);this.headerStr=q(this.buf.slice(w-1,x));this.datarep=q(this.buf.slice(y-1,z));var b=
"IM"===this.datarep,e="IM"===this.datarep;this.headerList=this.headerStr.split(",").map(function(a){return a.trim()});this.matfile=this.headerList[0];this.platform=this.headerList[1];this.createdOn=this.headerList[2];this.subsystemOffset=q(this.buf.slice(A-1,B));this.version=d.getUint16(C-1,b);this.versionName=D[this.version];this.dataType=d.getUint32(E-1,b);this.dataTypeName=k[this.dataType].name;this.arraySize=d.getUint32(F-1,b);var c=G+1,b=d.getUint32(c-1,b),h=k[b].name,b=k[b].size,c=c+4;n(d,h,
c-1,e);c+=b;n(d,h,c-1,e);var c=c+b+b,g=d.getUint32(c-1,e),c=c+4,h=k[g].name,g=k[g].size;d.getUint32(c-1,e);var c=c+4,l=n(d,h,c-1,e),c=c+g;1<l&&window.console.warn("Only 1D arrays are currently supported.");n(d,h,c-1,e);c+=b;g=d.getUint32(c-1,e);c+=4;b=0;h=!1;15<g&&(g&=255,h=!0,b=d.getUint16(c-5,e));g=k[g].name;h||(b=n(d,g,c-1,e),c+=4);q(this.buf.slice(c-1,c+b-1));c+=b+(h?(4-b%4)%4:(8-b%8)%8);this.setData(this.buf,d,c,e)}}function r(a){var f=document.createElement("a");f.href=a;for(var d=f.protocol.replace(":",
""),b=f.hostname,e=f.port,c=f.search,h={},g=f.search.replace(/^\?/,"").split("&"),l=g.length,k=0,m;k<l;k++)g[k]&&(m=g[k].split("="),h[m[0]]=m[1]);return{source:a,protocol:d,host:b,port:e,query:c,params:h,file:(f.pathname.match(/\/([^\/?#]+)$/i)||[null,""])[1],hash:f.hash.replace("#",""),path:f.pathname.replace(/^([^\/])/,"/$1"),relative:(f.href.match(/tps?:\/\/[^\/]+(.+)/)||[null,""])[1],segments:f.pathname.replace(/^\//,"").split("/")}}function H(a,f,d){d=d||1024;var b=0,e=new ArrayBuffer(a.length),
c=new Uint8Array(e),h=function(){for(var g=b+d;b<g;b++)c[b]=a.charCodeAt(b)&255;b>=a.length?f(e):setTimeout(h,0)};setTimeout(h,0)}function u(a){this.options=a}m.navigator&&navigator.userAgent.match(/(iPad|iPhone|iPod)/i);var w=1,x=116,A=117,B=124,C=125,y=127,z=128,E=129,F=133,G=136;(function(){var a=new ArrayBuffer(4),f=new Uint32Array(a),a=new Uint8Array(a);f[0]=3735928559;if(239===a[0])return"LE";if(222===a[0])return"BE";throw Error("unknown endianness");})();var D={256:"MAT-file"},k={1:{name:"miINT8",
size:1},2:{name:"miUINT8",size:1},3:{name:"miINT16",size:2},4:{name:"miUINT16",size:2},5:{name:"miINT32",size:4},6:{name:"miUINT32",size:4},7:{name:"miSINGLE",size:4},9:{name:"miDOUBLE",size:8},12:{name:"miINT64",size:8},13:{name:"miUINT64",size:8},14:{name:"miMATRIX",size:null},15:{name:"miCOMPRESSED",size:null},16:{name:"miUTF8",size:null},17:{name:"miUTF16",size:null},18:{name:"miUTF32",size:null}},t=!0;try{var p=new Uint8Array(new ArrayBuffer(4));p[0]=66;p[1]=76;p[2]=85;p[3]=69;"BLUE"!==String.fromCharCode.apply(null,
p)&&(t=!1)}catch(I){t=!1}l.prototype={setData:function(a,f,d,b){var e,c=f.getUint32(d-1,b),h=!1;15<c?(c&=255,h=!0,e=f.getUint16(d+1,2,b)):d+=4;var g=k[c].name,c=k[c].size;h||(e=f.getUint32(d-1,b));this.dview=v(a,d+4-1,e/c,g)}};u.prototype={readheader:function(a,f){var d=this,b=new FileReader,e=a.webkitSlice(0,116);b.onloadend=function(a){return function(e){e.target.error?f(null):(e=new l(b.result,d.options),e.file=a,f(e))}}(a);b.readAsArrayBuffer(e)},read:function(a,f){var d=this,b=new FileReader;
b.onloadend=function(a){return function(c){c.target.error?f(null):(c=new l(b.result,d.options),c.file=a,c.file_name=a.name,f(c))}}(a);b.readAsArrayBuffer(a)},read_http:function(a,f){var d=this,b=new XMLHttpRequest;b.open("GET",a,!0);b.responseType="arraybuffer";b.overrideMimeType("text/plain; charset=x-user-defined");b.onload=function(e){if(4!==b.readyState||200!==b.status&&0!==b.status)f(null);else if(e=null,b.response){e=b.response;e=new l(e,d.options);r(a);var c=r(a);e.file_name=c.file;f(e)}else b.responseText&&
H(b.responseText,function(b){b=new l(b,d.options);r(a);var c=r(a);b.file_name=c.file;f(b)})};b.onerror=function(a){f(null)};b.send(null)}};m.MatHeader=m.MatHeader||l;m.MatFileReader=m.MatFileReader||u})(this);
