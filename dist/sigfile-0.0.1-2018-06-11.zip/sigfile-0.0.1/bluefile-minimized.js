/*

 File: bluefile.js
 Copyright (c) 2012-2017, LGS Innovations Inc., All rights reserved.

 This file is part of SigPlot.

 Licensed to the LGS Innovations (LGS) under one
 or more contributor license agreements.  See the NOTICE file
 distributed with this work for additional information
 regarding copyright ownership.  LGS licenses this file
 to you under the Apache License, Version 2.0 (the
 "License"); you may not use this file except in compliance
 with the License.  You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing,
 software distributed under the License is distributed on an
 "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 KIND, either express or implied.  See the License for the
 specific language governing permissions and limitations
 under the License.

*/
(function(){function z(b,d){for(var c in d){var a=d[c];"object"===typeof a?z(b[c],a):b[c]=a}return b}function k(){}function w(b){return 0<=b&&31>b?1<<b:w[b]||(w[b]=Math.pow(2,b))}function t(b){b=new Uint8Array(b);if(x)return String.fromCharCode.apply(null,b);for(var d="",c=0;c<b.length;c++)d+=String.fromCharCode(b[c]);return d}function u(b){var d=document.createElement("a");d.href=b;for(var c=d.protocol.replace(":",""),a=d.hostname,e=d.port,f=d.search,g={},h=d.search.replace(/^\?/,"").split("&"),
l=h.length,q=0,p;q<l;q++)h[q]&&(p=h[q].split("="),g[p[0]]=p[1]);return{source:b,protocol:c,host:a,port:e,query:f,params:g,file:(d.pathname.match(/\/([^\/?#]+)$/i)||[null,""])[1],hash:d.hash.replace("#",""),path:d.pathname.replace(/^([^\/])/,"/$1"),relative:(d.href.match(/tps?:\/\/[^\/]+(.+)/)||[null,""])[1],segments:d.pathname.replace(/^\//,"").split("/")}}function B(b,d,c){c=c||1024;var a=0,e=new ArrayBuffer(b.length),f=new Uint8Array(e),g=function(){for(var h=a+c;a<h;a++)f[a]=b.charCodeAt(a)&255;
a>=b.length?d(e):setTimeout(g,0)};setTimeout(g,0)}void 0!==global.navigator&&navigator.userAgent.match(/(iPad|iPhone|iPod)/i);var m=function(){var b=new ArrayBuffer(4),d=new Uint32Array(b),b=new Uint8Array(b);d[0]=3735928559;if(239===b[0])return"LE";if(222===b[0])return"BE";throw Error("unknown endianness");}(),A={S:1,C:2,V:3,Q:4,M:9,X:10,T:16,U:1,1:1,2:2,3:3,4:4,5:5,6:6,7:7,8:8,9:9},y={P:0.125,A:1,O:1,B:1,I:2,L:4,X:8,F:4,D:8},C={P:null,A:null,O:Uint8Array,B:Int8Array,I:Int16Array,L:Int32Array,X:null,
F:Float32Array,D:Float64Array},v={P:null,A:null,O:"getUint8",B:"getInt8",I:"getInt16",L:"getInt32",X:function(b,d,c){var a,e,f=Math.pow(2,53);c?(a=4,e=0):(a=0,e=4);a=b.getInt32(d+a,c);b=b.getInt32(d+e,c)+w(32)*a;return b>=f?Infinity:b},F:"getFloat32",D:"getFloat64"},x=!0;try{var r=new Uint8Array(new ArrayBuffer(4));r[0]=66;r[1]=76;r[2]=85;r[3]=69;"BLUE"!==String.fromCharCode.apply(null,r)&&(x=!1)}catch(D){x=!1}k.BlueHeader=function(b,d){this.options={read_ext_header:!0,ext_header_type:"dict"};z(this.options,
d);this.buf=b;if(null!=this.buf){var c=new DataView(this.buf);this.version=t(this.buf.slice(0,4));this.headrep=t(this.buf.slice(4,8));this.datarep=t(this.buf.slice(8,12));var a;if("IEEE"!==this.headrep&&"EEEI"!==this.headrep)throw"invalid headrep, is this a bluefile?"+this.headrep;if("IEEE"===this.datarep)a=!1;else if("EEEI"===this.datarep)a=!0;else throw"invalid headrep, is this a bluefile?"+this.headrep;this.ext_start=c.getInt32(24,a);this.ext_size=c.getInt32(28,a);this.type=c.getUint32(48,a);this["class"]=
this.type/1E3;this.format=t(this.buf.slice(52,54));this.timecode=c.getFloat64(56,a);1===this["class"]?(this.xstart=c.getFloat64(256,a),this.xdelta=c.getFloat64(264,a),this.xunits=c.getInt32(272,a),this.yunits=c.getInt32(296,a),this.subsize=1):2===this["class"]&&(this.xstart=c.getFloat64(256,a),this.xdelta=c.getFloat64(264,a),this.xunits=c.getInt32(272,a),this.subsize=c.getInt32(276,a),this.ystart=c.getFloat64(280,a),this.ydelta=c.getFloat64(288,a),this.yunits=c.getInt32(296,a));this.data_start=c.getFloat64(32,
a);this.data_size=c.getFloat64(40,a);var c=this.data_start,e=this.data_start+this.data_size;this.ext_size&&this.options.read_ext_header&&(this.ext_header=this.unpack_keywords(this.buf,this.ext_size,512*this.ext_start,a));this.options.hdronly||this.setData(this.buf,c,e,void 0)}};k.BlueHeader.prototype={setData:function(b,d,c,a){1===this["class"]?(this.spa=A[this.format[0]],this.bps=y[this.format[1]],this.bpa=this.spa*this.bps,this.ape=1,this.bpe=this.ape*this.bpa):2===this["class"]&&(this.spa=A[this.format[0]],
this.bps=y[this.format[1]],this.bpa=this.spa*this.bps,this.ape=this.subsize,this.bpe=this.ape*this.bpa);void 0===a&&(a="LE"===m);if("LE"===m&&!a)throw"Not supported "+m+" "+a;if("BE"===m&&this.littleEndianData)throw"Not supported "+m+" "+a;b?(this.dview=d&&c?this.createArray(b,d,(c-d)/this.bps):this.createArray(b),this.size=this.dview.length/(this.spa*this.ape)):this.dview=this.createArray(null,null,this.size)},unpack_keywords:function(b,d,c,a){var e,f,g,h,l,q=[],p={},k={},n=0,s=b.slice(c,c+d);if(s.byteLength!==
d)throw"header specifies invalid ext_start/ext_size";for(var m=new DataView(s),s=t(s);n<d;)l=n+8,b=m.getUint32(n,a),e=m.getInt16(n+4,a),f=m.getInt8(n+6,a),c=s.slice(n+7,n+8),e=b-e,h=l+e,f=s.slice(h,h+f),"A"===c?g=s.slice(l,l+e):v[c]&&(g="string"===typeof v[c]?m[v[c]](l,a):v[c](m,l,a)),"undefined"===typeof p[f]?p[f]=1:(p[f]++,f=""+f+p[f]),k[f]=g,q.push({tag:f,value:g}),n+=b;d=["dict","json",{},"XMTable","JSON","DICT"];for(var r in d)if(d[r]===this.options.ext_header_type)return k;return q},createArray:function(b,
d,c){var a=C[this.format[1]];if(void 0===a)throw"unknown format "+this.format[1];void 0===d&&(d=0);void 0===c&&(c=b.length||b.byteLength/y[this.format[1]]);return b?new a(b,d,c):new a(c)}};k.BlueFileReader=function(b){this.options=b};k.BlueFileReader.prototype={readheader:function(b,d){var c=this;if("undefined"!==typeof document&&"undefined"!==typeof FileReader){var a=new FileReader,e=b.webkitSlice(0,512);a.onloadend=function(b){return function(e){e.target.error?d(null):(e=new k.BlueHeader(a.result,
c.options),e.file=b,d(e))}}(b);a.readAsArrayBuffer(e)}else{var f=require("buffer").Buffer,g=require("fs").createReadStream(b,{start:0,end:511}),h,l;g.on("readable",function(){for(;null!=(l=g.read());)h=h?f.concat([h,l]):l});g.on("end",function(){var a=new k.BlueHeader(h.buffer,c.options);a.file_name=b;d(a)})}},read:function(b,d){var c=this,a=new FileReader;a.onloadend=function(b){return function(f){f.target.error?d(null):(f=new k.BlueHeader(a.result,c.options),f.file=b,f.file_name=b.name,d(f))}}(b);
a.readAsArrayBuffer(b)},read_http:function(b,d){var c=this,a=new XMLHttpRequest;a.open("GET",b,!0);a.responseType="arraybuffer";a.overrideMimeType("text/plain; charset=x-user-defined");a.onload=function(e){if(4!==a.readyState||200!==a.status&&0!==a.status)d(null);else if(e=null,a.response){e=a.response;e=new k.BlueHeader(e,c.options);u(b);var f=u(b);e.file_name=f.file;d(e)}else a.responseText&&B(a.responseText,function(a){a=new k.BlueHeader(a,c.options);u(b);var e=u(b);a.file_name=e.file;d(a)})};
a.onerror=function(a){d(null)};a.send(null)}};module.exports=k})();
